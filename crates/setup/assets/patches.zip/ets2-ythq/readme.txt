YTHQ Tablet × WestPlay 桥接 (ETS2) v1.3

v1.3：
  - YTHQ 屏幕模型只采样贴图中间 V=0.192..0.808 的一条带，WestPlay
    画面因此只显示中间 61.6%，看起来被放大/裁切。现已把 194 个平板
    屏幕片的 UV 重映射到完整 0..1；只改 UV，不改几何。
  - 配合下面的 1.425:1 等比叠层，大/小平板都能满屏显示完整画面。

v1.2：
  - 比例改为按 WestPlay 原版平板的 1.425:1 等比显示。
  - YTHQ 屏幕较窄，叠层左右各外扩约 2.67% 后裁掉，不再横向拉伸。

v1.1 修复：
  - 叠层 UI 单元名过长（_nameless._.westplay_bridge，27 字符）导致
    SCS 报 “unit name ... is in wrong format”，加载平板 UI 时闪退。
  - 现改为 _nameless._.wpb，长度安全。

适用于：
  - YTHQ Tablet（创意工坊）
  - WestPlay 2.4.0 或更新的改进版（含“车辆屏幕 / 平板”显示切换）

作用：
  在 YTHQ 大平板与小平板的原界面之上叠加 WestPlay 的 tablet 实时画面。
  只覆盖 YTHQ 平板仪表 UI 脚本，不改动模型、材质、贴图或 UV。

显示优先级：
  - WestPlay 选择“平板”时：叠层显示 WestPlay，原 YTHQ 界面被覆盖。
  - WestPlay 选择“车辆屏幕”，或该车原车屏幕正在显示 WestPlay 时：
    WestPlay 会把 tablet 贴图清成透明，叠层消失，YTHQ 原界面照常显示。
  - 未运行 WestPlay 客户端时：显示 WestPlay 的占位画面（正常现象）。

比例：
  按 WestPlay 原版平板的 1.425:1 画面比例显示，不拉伸。
  YTHQ 屏幕约 1.353:1，所以叠层比屏幕宽约 5.33%，由窗口裁掉左右各约
  2.67%；大小平板共用同一套 UI，比例一致。这样图标、文字和地图都保持
  原版平板的形状，不再横向变宽。

安装：
  1. 把 zz_ythq_westplay_bridge.scs 放进 文档\Euro Truck Simulator 2\mod\。
  2. 在模组管理器中启用，并放在 YTHQ Tablet 之上（更高优先级）。
  3. 车内已装 YTHQ 平板即可，无需重新购买。
